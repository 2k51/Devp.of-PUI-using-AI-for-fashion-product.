CREATE DATABASE fashion_payment_issues;

USE fashion_payment_issues;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(100),
    preferences TEXT
);

CREATE TABLE transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(10, 2),
    status VARCHAR(50),
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE payment_issues (
    issue_id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT,
    issue_type VARCHAR(100),
    status VARCHAR(50),
    resolution_date TIMESTAMP NULL,
    comments TEXT,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);
INSERT INTO users (name, email, password, preferences) VALUES
('Alice Johnson', 'alice@example.com', 'hashed_password_1', '[]'),
('Bob Smith', 'bob@example.com', 'hashed_password_2', '[]'),
('Charlie Brown', 'charlie@example.com', 'hashed_password_3', '[]'),
('David Lee', 'david@example.com', 'hashed_password_4', '[]'),
('Emma Davis', 'emma@example.com', 'hashed_password_5', '[]'),
('Fiona Adams', 'fiona@example.com', 'hashed_password_6', '[]'),
('George Clark', 'george@example.com', 'hashed_password_7', '[]'),
('Hannah Scott', 'hannah@example.com', 'hashed_password_8', '[]'),
('Ian Moore', 'ian@example.com', 'hashed_password_9', '[]'),
('Jane Turner', 'jane@example.com', 'hashed_password_10', '[]'),
('Kevin White', 'kevin@example.com', 'hashed_password_11', '[]'),
('Laura Wilson', 'laura@example.com', 'hashed_password_12', '[]'),
('Mike Evans', 'mike@example.com', 'hashed_password_13', '[]'),
('Nina Hill', 'nina@example.com', 'hashed_password_14', '[]'),
('Oliver Young', 'oliver@example.com', 'hashed_password_15', '[]'),
('Paula Harris', 'paula@example.com', 'hashed_password_16', '[]'),
('Quincy Martin', 'quincy@example.com', 'hashed_password_17', '[]'),
('Rachel Green', 'rachel@example.com', 'hashed_password_18', '[]'),
('Steve Baker', 'steve@example.com', 'hashed_password_19', '[]'),
('Tina Morris', 'tina@example.com', 'hashed_password_20', '[]');

INSERT INTO transactions (user_id, amount, status, date, payment_method) VALUES
(1, 49.99, 'Completed', '2024-08-01 14:30:00', 'Credit Card'),
(2, 75.50, 'Completed', '2024-08-02 11:15:00', 'PayPal'),
(3, 120.00, 'Failed', '2024-08-03 09:45:00', 'Debit Card'),
(4, 35.75, 'Pending', '2024-08-04 16:20:00', 'Credit Card'),
(5, 60.00, 'Completed', '2024-08-05 10:10:00', 'Bank Transfer'),
(6, 90.25, 'Failed', '2024-08-06 13:50:00', 'Credit Card'),
(7, 150.00, 'Completed', '2024-08-07 18:00:00', 'PayPal'),
(8, 40.50, 'Pending', '2024-08-08 12:30:00', 'Debit Card'),
(9, 85.99, 'Completed', '2024-08-09 15:15:00', 'Credit Card'),
(10, 200.00, 'Failed', '2024-08-10 17:45:00', 'PayPal'),
(11, 55.49, 'Completed', '2024-08-11 14:30:00', 'Bank Transfer'),
(12, 70.75, 'Pending', '2024-08-12 11:15:00', 'Credit Card'),
(13, 130.00, 'Completed', '2024-08-13 09:45:00', 'Debit Card'),
(14, 45.75, 'Failed', '2024-08-14 16:20:00', 'PayPal'),
(15, 100.00, 'Completed', '2024-08-15 10:10:00', 'Credit Card'),
(16, 80.25, 'Pending', '2024-08-16 13:50:00', 'Bank Transfer'),
(17, 160.00, 'Completed', '2024-08-17 18:00:00', 'Debit Card'),
(18, 70.50, 'Failed', '2024-08-18 12:30:00', 'Credit Card'),
(19, 95.99, 'Completed', '2024-08-19 15:15:00', 'PayPal'),
(20, 220.00, 'Pending', '2024-08-20 17:45:00', 'Bank Transfer');

INSERT INTO payment_issues (transaction_id, issue_type, status, resolution_date, comments) VALUES
(3, 'Failed Payment', 'Resolved', '2024-08-04 10:00:00', 'Issue with debit card processing. Refund issued.'),
(6, 'Failed Payment', 'Pending', NULL, 'Investigating the issue with credit card provider.'),
(8, 'Delayed Payment', 'Resolved', '2024-08-09 13:00:00', 'Payment was processed successfully after delay.'),
(10, 'Failed Payment', 'Resolved', '2024-08-11 09:00:00', 'PayPal payment failed. Refund issued.'),
(14, 'Failed Payment', 'Pending', NULL, 'Issue reported to PayPal for resolution.'),
(16, 'Delayed Payment', 'Resolved', '2024-08-17 12:00:00', 'Bank transfer delay resolved.'),
(18, 'Failed Payment', 'Pending', NULL, 'Credit card transaction failed. Investigating.'),
(20, 'Delayed Payment', 'Resolved', '2024-08-21 14:00:00', 'Bank transfer completed after delay.');
