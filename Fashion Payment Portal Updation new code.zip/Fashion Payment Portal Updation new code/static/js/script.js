$(document).ready(function() {
    // Example: Handle AJAX form submission (optional)
    $('form').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            method: $(this).attr('method'),
            data: $(this).serialize(),
            success: function(response) {
                alert('Form submitted successfully');
            },
            error: function(response) {
                alert('Error submitting form');
            }
        });
    });
});

