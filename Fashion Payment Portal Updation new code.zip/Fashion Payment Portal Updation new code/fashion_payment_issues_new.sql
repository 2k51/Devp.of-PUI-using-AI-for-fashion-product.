-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: fashion_payment_issues
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payment_issues`
--

DROP TABLE IF EXISTS `payment_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_issues` (
  `issue_id` int NOT NULL AUTO_INCREMENT,
  `transaction_id` int DEFAULT NULL,
  `issue_type` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `resolution_date` timestamp NULL DEFAULT NULL,
  `comments` text,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`issue_id`),
  KEY `transaction_id` (`transaction_id`),
  CONSTRAINT `payment_issues_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_issues`
--

LOCK TABLES `payment_issues` WRITE;
/*!40000 ALTER TABLE `payment_issues` DISABLE KEYS */;
INSERT INTO `payment_issues` VALUES (4,3,'Failed Payment','Resolved','2024-08-04 04:30:00','Issue with debit card processing. Refund issued.',NULL),(5,6,'Failed Payment','Pending',NULL,'Investigating the issue with credit card provider.',NULL),(6,8,'Delayed Payment','Resolved','2024-08-09 07:30:00','Payment was processed successfully after delay.',NULL),(7,10,'Failed Payment','Resolved','2024-08-11 03:30:00','PayPal payment failed. Refund issued.',NULL),(8,14,'Failed Payment','Pending',NULL,'Issue reported to PayPal for resolution.',NULL),(9,16,'Delayed Payment','Resolved','2024-08-17 06:30:00','Bank transfer delay resolved.',NULL),(10,18,'Failed Payment','Pending',NULL,'Credit card transaction failed. Investigating.',NULL),(11,20,'Delayed Payment','Resolved','2024-08-21 08:30:00','Bank transfer completed after delay.',NULL),(12,20,'Delayed Payment','Pending',NULL,'Issue with debit card processing. Refund issued.',NULL),(13,18,'AAA','Pending',NULL,'fsdf',NULL),(15,2,'AAA','Pending',NULL,'fsdfsd',NULL),(16,7,'werw','Pending',NULL,'wer',NULL),(17,8,'Sample Issue','Pending',NULL,'Comment',NULL),(18,3,'AAA','Pending',NULL,'131312',NULL),(19,1,'Delayed Payment','Pending',NULL,'ASAS',21),(20,10,'Delayed Payment','Pending',NULL,'SDS',21),(21,13,'Delayed Payment','Resolved','2024-09-19 18:30:00','SDGHSDGFSDH',21),(22,1,'Delayed Payment','Pending','2024-09-26 18:30:00','Enter Comment Hear',27),(23,16,'Payment Gateway Failure','Resolved','2024-09-25 18:30:00','New Comment',27),(24,13,'Delayed Payment','Pending','2024-09-10 18:30:00','Comment',28);
/*!40000 ALTER TABLE `payment_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `transaction_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_method` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,49.99,'Completed','2024-08-01 09:00:00','Credit Card'),(2,2,75.50,'Completed','2024-08-02 05:45:00','PayPal'),(3,3,120.00,'Failed','2024-08-03 04:15:00','Debit Card'),(4,4,35.75,'Pending','2024-08-04 10:50:00','Credit Card'),(5,5,60.00,'Completed','2024-08-05 04:40:00','Bank Transfer'),(6,6,90.25,'Failed','2024-08-06 08:20:00','Credit Card'),(7,7,150.00,'Completed','2024-08-07 12:30:00','PayPal'),(8,8,40.50,'Pending','2024-08-08 07:00:00','Debit Card'),(9,9,85.99,'Completed','2024-08-09 09:45:00','Credit Card'),(10,10,200.00,'Failed','2024-08-10 12:15:00','PayPal'),(11,11,55.49,'Completed','2024-08-11 09:00:00','Bank Transfer'),(12,12,70.75,'Pending','2024-08-12 05:45:00','Credit Card'),(13,13,130.00,'Completed','2024-08-13 04:15:00','Debit Card'),(14,14,45.75,'Failed','2024-08-14 10:50:00','PayPal'),(15,15,100.00,'Completed','2024-08-15 04:40:00','Credit Card'),(16,16,80.25,'Pending','2024-08-16 08:20:00','Bank Transfer'),(17,17,160.00,'Completed','2024-08-17 12:30:00','Debit Card'),(18,18,70.50,'Failed','2024-08-18 07:00:00','Credit Card'),(19,19,95.99,'Completed','2024-08-19 09:45:00','PayPal'),(20,20,220.00,'Pending','2024-08-20 12:15:00','Bank Transfer');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `preferences` text,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Alice Johnson','alice@example.com','hashed_password_1','[]'),(2,'Bob Smith','bob@example.com','hashed_password_2','[]'),(3,'Charlie Brown','charlie@example.com','hashed_password_3','[]'),(4,'David Lee','david@example.com','hashed_password_4','[]'),(5,'Emma Davis','emma@example.com','hashed_password_5','[]'),(6,'Fiona Adams','fiona@example.com','hashed_password_6','[]'),(7,'George Clark','george@example.com','hashed_password_7','[]'),(8,'Hannah Scott','hannah@example.com','hashed_password_8','[]'),(9,'Ian Moore','ian@example.com','hashed_password_9','[]'),(10,'Jane Turner','jane@example.com','hashed_password_10','[]'),(11,'Kevin White','kevin@example.com','hashed_password_11','[]'),(12,'Laura Wilson','laura@example.com','hashed_password_12','[]'),(13,'Mike Evans','mike@example.com','hashed_password_13','[]'),(14,'Nina Hill','nina@example.com','hashed_password_14','[]'),(15,'Oliver Young','oliver@example.com','hashed_password_15','[]'),(16,'Paula Harris','paula@example.com','hashed_password_16','[]'),(17,'Quincy Martin','quincy@example.com','hashed_password_17','[]'),(18,'Rachel Green','rachel@example.com','hashed_password_18','[]'),(19,'Steve Baker','steve@example.com','hashed_password_19','[]'),(20,'Tina Morris','tina@example.com','hashed_password_20','[]'),(21,'Ravindra Warnasooriya','warnasooriya.ravindra@gmail.com','scrypt:32768:8:1$XSEkKeUXcZEkQSc4$5c0893db9aafef277d77d93d6de19da722abc14ef20a814d059795443482e7aa2beed181c9979d7511007d6b5d2048a59113041e38c5a41c09ae17a51ab384f2',NULL),(22,'Asanka','asanka@gmail.com','scrypt:32768:8:1$XSEIQgjZqhxV3HAe$1e84dcefa1fde51d044d74250a135f3d095d017f3ab64e5199253649bb3d43f7c22fbadd2b7846ae431b469cadb367bbcf013579d9dade16fc7cff57537b5017',NULL),(24,'eranda','eranda@gmail.com','scrypt:32768:8:1$oEEKmsmelAIqwJhx$b0a8bb9b1d8fe6e0eb8ea8c83507d237af82dcf43711f28756d957f6dd0ac1c532d9a2e2855d916d9c31d5cc0833535da12da55f8d5c756f582db1fd331a4464',NULL),(25,'kamal','kamal@gmail.com','scrypt:32768:8:1$45JtnjNRl9KW9EJM$b63abd778547ca672616785a3595b5626deb1661eb478dc16f753dd091f9f9d1996e84fbc0976a994c649bd259ecf7739a9477a77fe5fc65c07f016df62c146e',NULL),(26,'Asanka Sandaruwan','asa@gmail.com','scrypt:32768:8:1$ES0Agr6UMXfxyfGH$85ee440295eabd2755f564df301fe8eca38d632841a3911724aa4a9bc37e342a1e59f03257482bb3119ec68e6c7813cb07a665cdf4495b9de7868f6b735517e4',NULL),(27,'sanath','sanath@gmail.com','scrypt:32768:8:1$ke0VRtnXMv1bGaWg$0453464210223334d48e3c5d5d5a3bf30aa6939ebf3ec3cf7078afe8fbf1cfd92a68352491c9ad2ef59a4857f7849eeaede4e52a8d8d723129428f11cd2ee8ec',NULL),(28,'sarath','sarath@gmail.com','scrypt:32768:8:1$LoE1vIwhXmO2HqmU$2b7177694506b9a3c845686d93fb47e9eb74b8d14cbc56af0e1470e753fa390e531ee787ae9c7b55b7056c895a907940fca975e64946bcf4d545a23f00255a1c',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-07 14:31:58
