from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="1Kiran@1989#",
    database="fashion_payment_issues"
)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        
        cursor = db.cursor()
        cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", 
                       (name, email, password))
        db.commit()
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['user_id']
            session['name'] = user['name']
            return redirect(url_for('profile'))
        else:
            return "Invalid login"
    
    return render_template('login.html')

@app.route('/profile')
def profile():
    if 'user_id' in session:
        user_id = session['user_id']
        cursor = db.cursor(dictionary=True)
        # cursor.execute("SELECT * FROM transactions WHERE user_id = %s", (user_id,))
        cursor.execute("SELECT * FROM transactions")
        transactions = cursor.fetchall()
        return render_template('profile.html', transactions=transactions)
    else:
        return redirect(url_for('login'))

@app.route('/solutions_for_payment_issues')
def solutions_for_payment_issues():
    return render_template('solutions_for_payment_issues.html')
 

@app.route('/payment_issues_available')
def transactions_history():
    if 'user_id' in session:
        user_id = session['user_id']
        cursor = db.cursor(dictionary=True)
        # cursor.execute("SELECT * FROM transactions WHERE user_id = %s", (user_id,))
        cursor.execute("SELECT * FROM transactions")
        transactions = cursor.fetchall()
        return render_template('transaction_history.html', transactions=transactions)
    else:
        return redirect(url_for('login'))

@app.route('/payment_issues')
def payment_issues():
    if 'user_id' in session:
        user_id = session['user_id']
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM payment_issues where user_id = %s", (user_id,))
        issues = cursor.fetchall()

        cursor.execute("SELECT transaction_id , concat(transaction_id,' - ',amount,' - ',status,' - ' ,date , ' - ' ,payment_method) as issue FROM transactions")
        transactions = cursor.fetchall()
        return render_template('payment_issues.html', issues=issues , transactions = transactions)
    else:
        return redirect(url_for('login'))

@app.route('/submit_issue', methods=['POST'])
def submit_issue():
    transaction_id = request.form['transaction_id']
    issue_type = request.form['issue_type']
    comments = request.form['comments']
    user_id = session['user_id']
    status = request.form['status']
    resalution_date = request.form['resolution_date']
    cursor = db.cursor()
    cursor.execute("INSERT INTO payment_issues (transaction_id, issue_type, status, comments, user_id,resolution_date) VALUES (%s, %s, %s, %s, %s, %s)", 
                   (transaction_id, issue_type, status, comments, user_id, resalution_date))
    db.commit()
    return redirect(url_for('payment_issues'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('name', None)
    return redirect(url_for('home'))

if __name__ == "__main__":
    app.run(debug=True)
